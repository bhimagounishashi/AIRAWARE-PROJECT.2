import { useEffect, useMemo, useState, type FormEvent } from 'react'
import { Activity, ArrowDownRight, Wind, Search, MapPin, RefreshCw, Leaf, ShieldCheck, Sun, Cloud, AlertCircle, Menu } from 'lucide-react'
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { getAirQuality, searchCity } from './api'
import type { AirReading, GeoResult } from './types'

type Level = { label: string; advice: string; color: string; soft: string; range: string }
function getLevel(aqi: number): Level {
  if (aqi <= 50) return { label: 'Good', advice: 'Air quality is satisfactory. It’s a great day to enjoy the outdoors.', color: '#42c99a', soft: '#e3f8ef', range: '0–50' }
  if (aqi <= 100) return { label: 'Moderate', advice: 'Air quality is acceptable. Unusually sensitive people should consider limiting prolonged outdoor exertion.', color: '#e8b84e', soft: '#fff5d9', range: '51–100' }
  if (aqi <= 150) return { label: 'Unhealthy for sensitive groups', advice: 'Sensitive groups may experience health effects. Consider reducing prolonged outdoor activity.', color: '#ed914d', soft: '#fff0e3', range: '101–150' }
  if (aqi <= 200) return { label: 'Unhealthy', advice: 'Some members of the public may experience health effects. Reduce prolonged outdoor exertion.', color: '#e45d66', soft: '#ffeaec', range: '151–200' }
  if (aqi <= 300) return { label: 'Very unhealthy', advice: 'Health alert: everyone may begin to experience health effects. Limit outdoor activity.', color: '#9c78d8', soft: '#f1eafe', range: '201–300' }
  return { label: 'Hazardous', advice: 'Health warning of emergency conditions. Avoid outdoor activity and follow local health guidance.', color: '#a65b45', soft: '#f8e9e3', range: '301+' }
}

const SCALE = [
  { range: '0–50', name: 'Good', note: 'Enjoy outdoor activities', color: '#42c99a' },
  { range: '51–100', name: 'Moderate', note: 'Acceptable for most people', color: '#e8b84e' },
  { range: '101–150', name: 'Sensitive groups', note: 'Reduce prolonged exertion', color: '#ed914d' },
  { range: '151–200', name: 'Unhealthy', note: 'Limit outdoor exertion', color: '#e45d66' },
  { range: '201–300', name: 'Very unhealthy', note: 'Health alert for everyone', color: '#9c78d8' },
  { range: '301+', name: 'Hazardous', note: 'Avoid outdoor activity', color: '#a65b45' },
]

const START_CITY: GeoResult = { id: 1264527, name: 'Hyderabad', latitude: 17.385, longitude: 78.4867, country: 'India', admin1: 'Telangana' }

function App() {
  const [place, setPlace] = useState<GeoResult>(START_CITY)
  const [reading, setReading] = useState<AirReading | null>(null)
  const [query, setQuery] = useState('')
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [refreshKey, setRefreshKey] = useState(0)
  const [activeTab, setActiveTab] = useState<'overview' | 'scale'>('overview')

  useEffect(() => {
    let alive = true
    setLoading(true)
    setError('')
    getAirQuality(place)
      .then((data) => { if (alive) setReading(data) })
      .catch((err: unknown) => { if (alive) setError(err instanceof Error ? err.message : 'Something went wrong.') })
      .finally(() => { if (alive) setLoading(false) })
    return () => { alive = false }
  }, [place, refreshKey])

  async function handleSearch(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!query.trim()) return
    setLoading(true)
    setError('')
    try {
      const found = await searchCity(query.trim())
      setPlace(found)
      setQuery('')
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not search for that city.')
      setLoading(false)
    }
  }

  const level = reading ? getLevel(reading.aqi) : getLevel(0)
  const chartData = useMemo(() => reading?.hourly.map((item) => ({
    ...item,
    hour: new Date(item.time).toLocaleTimeString([], { hour: 'numeric' }),
  })) ?? [], [reading])
  const formattedTime = reading ? new Date(reading.updatedAt).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }) : '—'

  return (
    <div className="app-shell">
      <header className="topbar">
        <a className="brand" href="#" aria-label="AirAware home">
          <span className="brand-mark"><Wind size={21} strokeWidth={2.3} /></span>
          <span>air<span className="brand-light">aware</span><small>THE AIR QUALITY COMPANION</small></span>
        </a>
        <nav className="desktop-nav" aria-label="Main navigation">
          <button className={activeTab === 'overview' ? 'nav-link active' : 'nav-link'} onClick={() => setActiveTab('overview')}>Dashboard</button>
          <button className={activeTab === 'scale' ? 'nav-link active' : 'nav-link'} onClick={() => setActiveTab('scale')}>AQI guide</button>
          <a className="nav-link" href="/static-phase.html">Static AQI guide</a>
          <a className="nav-link" href="#about">About</a>
        </nav>
        <div className="live-pill"><span className="live-dot" /> LIVE DATA</div>
        <button className="mobile-menu" aria-label="Open menu" onClick={() => setActiveTab(activeTab === 'overview' ? 'scale' : 'overview')}><Menu /></button>
      </header>

      <main>
        <section className="hero">
          <div className="hero-copy">
            <div className="eyebrow"><span /> BREATHE BETTER. LIVE BETTER.</div>
            <h1>Know the air<br />you <em>breathe.</em></h1>
            <p className="hero-description">A clearer picture of the air around you. Explore real-time air quality, understand what it means, and make healthier choices every day.</p>
            <div className="hero-meta"><span><Activity size={15} /> Live air insights</span><span><ShieldCheck size={15} /> Health-first guidance</span></div>
          </div>
          <div className="hero-art" aria-hidden="true">
            <div className="orb orb-one" /><div className="orb orb-two" />
            <div className="sun-disc"><Sun size={48} strokeWidth={1.1} /></div>
            <div className="art-hill hill-back" /><div className="art-hill hill-front" />
            <div className="art-label"><span className="art-label-dot" /> A healthier tomorrow starts with awareness</div>
          </div>
        </section>

        <section className="dashboard-section" id="dashboard">
          <div className="section-heading">
            <div><div className="eyebrow dark-eyebrow">YOUR AIR, AT A GLANCE</div><h2>Air quality dashboard</h2></div>
            <div className="updated"><span className="live-dot" /> {reading ? `Updated ${formattedTime}` : 'Connecting to live data'}</div>
          </div>

          <div className="location-toolbar">
            <div className="location-current"><MapPin size={17} /><div><strong>{place.name}</strong><span>{[place.admin1, place.country].filter(Boolean).join(', ')}</span></div></div>
            <form className="search-form" onSubmit={handleSearch}>
              <Search size={17} /><input aria-label="Search city" placeholder="Search for a city..." value={query} onChange={(e) => setQuery(e.target.value)} />
              <button type="submit" disabled={loading}>Explore</button>
            </form>
            <button className="refresh-button" aria-label="Refresh air quality" onClick={() => setRefreshKey((key) => key + 1)} disabled={loading}><RefreshCw size={17} className={loading ? 'spin' : ''} /></button>
          </div>

          {error && <div className="error-message"><AlertCircle size={18} />{error}</div>}

          <div className="dashboard-grid">
            <article className="aqi-card">
              <div className="card-topline"><span className="card-kicker">CURRENT AIR QUALITY</span><span className="tiny-live"><span className="live-dot" /> LIVE</span></div>
              <div className="aqi-main">
                <div><div className="aqi-number">{loading && !reading ? '—' : reading?.aqi ?? '—'}</div><div className="aqi-caption">US AQI</div></div>
                <div className="aqi-status" style={{ background: level.soft, color: level.color }}><span className="status-dot" style={{ background: level.color }} />{loading && !reading ? 'Loading' : level.label}</div>
              </div>
              <div className="aqi-meter"><div className="meter-track"><span style={{ width: `${Math.min((reading?.aqi ?? 0) / 500 * 100, 100)}%`, background: level.color }} /></div><div className="meter-labels"><span>0 · Clean</span><span>500 · Severe</span></div></div>
              <p className="health-advice">{loading && !reading ? 'Fetching the latest air-quality reading...' : level.advice}</p>
              <div className="card-foot"><span><Activity size={15} /> Air quality index</span><span>Scale: 0–500</span></div>
            </article>

            <article className="metrics-card">
              <div className="card-topline"><span className="card-kicker">POLLUTANT SNAPSHOT</span><span className="metrics-icon"><Wind size={17} /></span></div>
              <div className="metrics-grid">
                <Metric label="PM2.5" value={reading?.pm25} unit="μg/m³" detail="Fine particles" />
                <Metric label="PM10" value={reading?.pm10} unit="μg/m³" detail="Coarse particles" />
                <Metric label="Ozone" value={reading?.ozone} unit="μg/m³" detail="Ground-level O₃" />
                <Metric label="Nitrogen dioxide" value={reading?.no2} unit="μg/m³" detail="Traffic-related NO₂" />
              </div>
              <div className="metrics-note"><Leaf size={15} /> Lower pollutant levels generally mean cleaner air.</div>
            </article>
          </div>

          <article className="chart-card">
            <div className="chart-header"><div><div className="card-kicker">WHAT'S AHEAD</div><h3>Air quality through the day</h3><p>Hourly forecast for {place.name}</p></div><div className="chart-legend"><span><i /> US AQI</span></div></div>
            {chartData.length > 0 ? (
              <div className="chart-wrap">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -18, bottom: 0 }}>
                    <defs><linearGradient id="aqiGradient" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#45c89b" stopOpacity={0.25} /><stop offset="95%" stopColor="#45c89b" stopOpacity={0.015} /></linearGradient></defs>
                    <CartesianGrid stroke="#edf1ef" vertical={false} />
                    <XAxis dataKey="hour" tick={{ fill: '#899590', fontSize: 11 }} axisLine={false} tickLine={false} interval={3} />
                    <YAxis tick={{ fill: '#899590', fontSize: 11 }} axisLine={false} tickLine={false} />
                    <Tooltip contentStyle={{ border: '1px solid #e8efeb', borderRadius: 12, boxShadow: '0 8px 24px #15352b12' }} formatter={(value) => [`${value} AQI`, 'US AQI']} />
                    <Area type="monotone" dataKey="aqi" stroke="#36b98c" strokeWidth={2.5} fill="url(#aqiGradient)" activeDot={{ r: 5, strokeWidth: 0 }} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            ) : <div className="chart-empty">{loading ? 'Loading hourly forecast…' : 'Hourly forecast will appear when data is available.'}</div>}
            <div className="chart-foot"><span><Cloud size={15} /> Forecast updates with the latest available model data</span><span>Next 24 hours</span></div>
          </article>
        </section>

        <section className="scale-section" id="scale">
          <div className="scale-intro"><div className="eyebrow dark-eyebrow">MAKE SENSE OF THE NUMBERS</div><h2>What does the AQI<br /><em>really mean?</em></h2><p>The Air Quality Index turns complex pollution data into a simple scale. The higher the number, the greater the health concern.</p><button className="text-link" onClick={() => setActiveTab('scale')}>Explore the AQI guide <ArrowDownRight size={16} /></button></div>
          <div className="scale-list">
            {SCALE.map((item, index) => <div className="scale-row" key={item.range}><span className="scale-color" style={{ background: item.color }} /><span className="scale-range">{item.range}</span><div className="scale-name"><strong>{item.name}</strong><small>{item.note}</small></div><span className="scale-number">0{index + 1}</span></div>)}
          </div>
        </section>

        <section className="takeaway" id="about">
          <div className="takeaway-icon"><Leaf size={25} /></div><div><div className="eyebrow">SMALL STEPS. BIG IMPACT.</div><h2>Awareness is the first breath of change.</h2><p>Check your local AQI before heading out. On poor-air days, keep windows closed when possible, reduce intense outdoor exercise, and follow advice from local health authorities.</p></div>
        </section>
      </main>

      <footer><a className="brand footer-brand" href="#"><span className="brand-mark"><Wind size={18} /></span><span>air<span className="brand-light">aware</span></span></a><span>Data powered by Open-Meteo · Built for a breath of fresh perspective.</span><a href="/static-phase.html">AQI explainer</a><a href="https://open-meteo.com/en/docs/air-quality-api" target="_blank" rel="noreferrer">Data source ↗</a></footer>
    </div>
  )
}

function Metric({ label, value, unit, detail }: { label: string; value?: number; unit: string; detail: string }) {
  return <div className="metric"><span className="metric-label">{label}</span><div className="metric-value">{value === undefined ? '—' : value}<small>{unit}</small></div><span className="metric-detail">{detail}</span></div>
}

export default App

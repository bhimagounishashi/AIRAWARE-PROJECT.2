import type { AirQualityResponse, AirReading, GeocodingResponse, GeoResult } from './types'

const GEO_URL = 'https://geocoding-api.open-meteo.com/v1/search'
const AIR_URL = 'https://air-quality-api.open-meteo.com/v1/air-quality'

export async function searchCity(name: string): Promise<GeoResult> {
  const url = new URL(GEO_URL)
  url.search = new URLSearchParams({ name, count: '1', language: 'en', format: 'json' }).toString()
  const response = await fetch(url)
  if (!response.ok) throw new Error('City search is temporarily unavailable.')
  const data = (await response.json()) as GeocodingResponse
  if (!data.results?.length) throw new Error(`We couldn't find “${name}”. Try another city.`)
  return data.results[0]
}

export async function getAirQuality(place: GeoResult): Promise<AirReading> {
  const url = new URL(AIR_URL)
  url.search = new URLSearchParams({
    latitude: String(place.latitude),
    longitude: String(place.longitude),
    current: 'us_aqi,pm2_5,pm10,ozone,nitrogen_dioxide',
    hourly: 'us_aqi,pm2_5',
    forecast_days: '1',
    timezone: 'auto',
  }).toString()

  const response = await fetch(url)
  if (!response.ok) throw new Error('Air-quality data is temporarily unavailable. Please try again.')
  const data = (await response.json()) as AirQualityResponse
  if (data.current?.us_aqi === undefined || data.current.us_aqi === null) {
    throw new Error('No current AQI reading was returned for this location. Please try again later.')
  }

  const hourly = (data.hourly?.time ?? []).slice(0, 24).map((time, index) => ({
    time,
    aqi: data.hourly?.us_aqi?.[index] ?? 0,
    pm25: data.hourly?.pm2_5?.[index] ?? 0,
  }))

  return {
    city: place.name,
    country: place.country ?? '',
    aqi: Math.round(data.current.us_aqi ?? 0),
    pm25: Number((data.current.pm2_5 ?? 0).toFixed(1)),
    pm10: Number((data.current.pm10 ?? 0).toFixed(1)),
    ozone: Number((data.current.ozone ?? 0).toFixed(1)),
    no2: Number((data.current.nitrogen_dioxide ?? 0).toFixed(1)),
    updatedAt: data.current.time,
    hourly,
  }
}

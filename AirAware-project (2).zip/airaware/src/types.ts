export interface GeoResult {
  id: number
  name: string
  latitude: number
  longitude: number
  country?: string
  admin1?: string
}

export interface GeocodingResponse {
  results?: GeoResult[]
}

export interface AirQualityCurrent {
  time: string
  us_aqi?: number
  pm2_5?: number
  pm10?: number
  ozone?: number
  nitrogen_dioxide?: number
}

export interface AirQualityHourly {
  time: string[]
  us_aqi?: number[]
  pm2_5?: number[]
}

export interface AirQualityResponse {
  current?: AirQualityCurrent
  hourly?: AirQualityHourly
  timezone?: string
}

export interface AirReading {
  city: string
  country: string
  aqi: number
  pm25: number
  pm10: number
  ozone: number
  no2: number
  updatedAt: string
  hourly: { time: string; aqi: number; pm25: number }[]
}

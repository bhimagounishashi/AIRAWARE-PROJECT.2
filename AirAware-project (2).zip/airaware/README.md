# AirAware — Air Quality Dashboard

**Project domain:** Agriculture, Environment & Smart City  
**Theme:** Air Quality Dashboard  
**Stack:** HTML5, CSS3, JavaScript, TypeScript, React, Fetch API, Vite, Recharts

AirAware helps people understand local air quality through an accessible AQI explainer and a live dashboard with city search, pollutant readings, health guidance and an hourly trend chart.

## Run the project

**Requirements:** Node.js 18 or later and npm.

```bash
npm install
npm run dev
```

Open the local URL shown by Vite (normally `http://localhost:5173`).

Production build and preview:

```bash
npm run build
npm run preview
```

## Pages

- `/` — Dynamic React dashboard. Starts with Hyderabad, India; search for another city to load its latest air-quality data.
- `/static-phase.html` — Standalone HTML/CSS AQI explainer for the static phase. Includes six AQI bands and common pollutant explanations.

## Requirements coverage checklist

| Brief requirement | Where it is implemented |
|---|---|
| Agriculture, Environment & Smart City domain | AirAware dashboard and AQI education content |
| AQI scale explainer page | `static-phase.html` |
| HTML and CSS static phase | `static-phase.html`, `static-phase.css` |
| CSS Grid | `.scale-grid`, `.pollutant-grid`, dashboard grids in `src/styles.css` |
| Mobile-first responsive media queries | `static-phase.css`, `src/styles.css` |
| Dynamic city AQI via API | `src/api.ts` (`searchCity`, `getAirQuality`) |
| React UI | `src/App.tsx` |
| TypeScript typed data | `src/types.ts`, typed API functions and component props |
| Fetch API | `fetch()` in `src/api.ts` |
| Colour-coded AQI cards | `getLevel()` and AQI status card in `src/App.tsx` |
| Trend chart | Recharts `AreaChart` in `src/App.tsx` |
| Loading and error handling | `loading`, `error`, guarded async state updates in `src/App.tsx` |
| City search and refresh | Dashboard search form and refresh control |

## API endpoints

AirAware uses Open-Meteo's public APIs; this demo does not require an API key.

- Geocoding: `https://geocoding-api.open-meteo.com/v1/search`
- Air quality: `https://air-quality-api.open-meteo.com/v1/air-quality`
- Documentation: https://open-meteo.com/en/docs/air-quality-api

The app requests current `us_aqi`, `pm2_5`, `pm10`, `ozone`, `nitrogen_dioxide` and hourly `us_aqi` / `pm2_5` values. Internet access is required. If the API is unavailable, the dashboard displays an error rather than pretending sample values are live.

## AQI bands used

| US AQI | Category |
|---:|---|
| 0–50 | Good |
| 51–100 | Moderate |
| 101–150 | Unhealthy for sensitive groups |
| 151–200 | Unhealthy |
| 201–300 | Very unhealthy |
| 301+ | Hazardous |

## Suggested project walkthrough / viva

1. Open `static-phase.html` and explain the semantic HTML sections, AQI categories, CSS Grid and mobile breakpoints.
2. Explain `src/types.ts`: `GeoResult`, API response interfaces and the normalized `AirReading` type.
3. Explain `searchCity()` and `getAirQuality()` in `src/api.ts`, including URL parameters, Fetch API, JSON parsing and error handling.
4. Explain `useEffect()` in `src/App.tsx`: it fetches data when the selected city changes and prevents state updates after cleanup.
5. Explain the `getLevel()` function and how AQI values map to colours and health advice.
6. Explain how `chartData` is prepared and passed to Recharts to draw the hourly AQI trend.

## Important note

Open-Meteo air-quality values are model-based estimates and may differ from readings at local regulatory monitoring stations. AirAware is an educational project, not a medical diagnosis or emergency alert service. Follow local public-health guidance.
